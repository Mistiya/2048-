#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <graphics.h>

void draw_num(int,int,int);
void start_game();
void square_clear();

int grade = 0;

int main() {
	initgraph(450, 610);
	square_clear();
	//draw_num(0,1,2048);
	//getchar();
	start_game();
}

//����
void test(int num[][4]){
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			settextstyle(20, 0, _T("����"));
			setcolor(WHITE);
			outtextxy(20*i,20*j,num[i][j]+'0');
		}
	}
}

//����Ҫ������С����λ��
int x_square(int i){
	i = 10*(i+1)+100*i;
	return i;
}

int y_square(int j){
	j = 10*(j+1)+100*j+150;
	return j;
}

//������ʼ����������
void square_clear(){
	int i,j;
	setcolor(BROWN);
	setfillcolor(BROWN);
	fillrectangle(0, 150, 450, 600);
	setcolor(BLACK);
	setfillcolor(BLACK);
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			fillrectangle(x_square(i),y_square(j),x_square(i)+100,y_square(j)+100);
		}
	}
}

//�������� x��yΪλ�� kΪ����
void draw_num(int y,int x,int k){
	int i,j,n=1;
	settextstyle(40, 0, _T("����"));
	setcolor(WHITE);
	if(k<10){
		outtextxy(x_square(x)+40, y_square(y)+30, k+'0');
	}
	//��outtextxy�ľ����ԣ��ֶ���λÿ������
	else if(k>10){
		j = k;
		while(j >= 10){
			j /= 10;
			n++;
		}
		n = (n-1)*10;
		for(i=n;i>=-n;i-=20){
			outtextxy(x_square(x)+40+i, y_square(y)+30, k%10+'0');
			k/=10;
		}
	}
}
/*
���ɷ���
�ڿյķ������������2��4
����Ѿ��������򷵻�0
*/
void create_square(int (*num)[4]){
	int i,j,k=0,sq[16],a;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			if(num[i][j] == 0){
				sq[k++] = i*10 + j;
			}
		}
	}
	k = rand()%k;
	a = rand()%2;
	draw_num(sq[k]/10,sq[k]%10,a*2+2);
	num[sq[k]/10][sq[k]%10] = a*2+2;
}

//�������黭��ͼ��
void draw_array(int num[4][4]){
	int i,j,k;
	square_clear();
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			if(num[i][j] != 0){
				draw_num(i,j,num[i][j]);
			}
		}
	}
}

//�󻬲���
void left(int (*num)[4]){
	int i,j,k;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 3; j++) {
			if (num[i][j] != 0) {
				for (k = j +1; k < 4; k++) {
					if (num[i][k] != 0) {
						if (num[i][k] == num[i][j]) {
							num[i][j] *= 2;
							num[i][k] = 0;
							j = k;
							break;
						}
						else {
							break;
						}
					}
				}
			}
		}
	}
	//����������£
	for(i=0;i<4;i++){
		for(j=0;j<3;j++){
			if(num[i][j] == 0){
				for(k=j+1;k<4;k++){
					if(num[i][k] != 0){
						num[i][j] = num[i][k];
						num[i][k] = 0;
						break;
					}
				}
			}
		}
	}
}

//�һ�����
void right(int (*num)[4]){
	int i,j,k;
	for (i = 0; i < 4; i++) {
		for (j = 3; j > 0; j--) {
			if (num[i][j] != 0) {
				for (k = j - 1; k >= 0; k--) {
					if (num[i][k] != 0) {
						if (num[i][k] == num[i][j]) {
							num[i][j] *= 2;
							num[i][k] = 0;
							j = k;
							break;
						}
						else {
							break;
						}
					}
				}
			}
		}
	}
	//���������ҿ�£
	for(i=0;i<4;i++){
		for(j=3;j>0;j--){
			if(num[i][j] == 0){
				for(k=j-1;k>=0;k--){
					if(num[i][k] != 0){
						num[i][j] = num[i][k];
						num[i][k] = 0;
						break;
					}
				}
			}
		}
	}
}

//�ϻ�����
void up(int (*num)[4]){
	int i,j,k;
	for (j = 0; j < 4; j++) {
		for (i = 0; i < 3; i++) {
			if (num[i][j] != 0) {
				for (k = i+1; k < 4; k++) {
					if (num[k][j] != 0) {
						if (num[i][j] == num[k][j]) {
							num[i][j] *= 2;
							num[k][j] = 0;
							i = k;
							break;
						}
						else {
							break;
						}
					}
				}
			}
		}
	}
	//���������Ͽ�£
	for(j=0;j<4;j++){
		for(i=0;i<3;i++){
			if(num[i][j] == 0){
				for(k=i+1;k<4;k++){
					if(num[k][j] != 0){
						num[i][j] = num[k][j];
						num[k][j] = 0;
						break;
					}
				}
			}
		}
	}
}

//�»�����
void down(int (*num)[4]){
	int i,j,k;
	for (j = 0; j < 4; j++) {
		for (i = 3; i > 0; i--) {
			if (num[i][j] != 0) {
				for (k = i - 1; k >= 0; k--) {
					if (num[k][j] != 0) {
						if (num[i][j] == num[k][j]) {
							num[i][j] *= 2;
							num[k][j] = 0;
							i = k;
							break;
						}
						else {
							break;
						}
					}
				}
			}
		}
	}
	//���������¿�£
	for(j=0;j<4;j++){
		for(i=3;i>0;i--){
			if(num[i][j] == 0){
				for(k=i-1;k>=0;k--){
					if(num[k][j] != 0){
						num[i][j] = num[k][j];
						num[k][j] = 0;
						break;
					}
				}
			}
		}
	}
}

//�Ƚ�������ά�����Ƿ����
int compare(int a[][4],int b[][4]){
	int i,j;
	for (i = 0; i < 4; i++) {
		for (j = 0; j < 4; j++) {
			if(a[i][j] != b[i][j])return 1;
		}
	}
	return 0;
}

//������ά���飬b����a
void copy(int a[][4],int b[][4]){
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			a[i][j] = b[i][j];
		}
	}
}

//�ж��Ƿ�gameover
int if_end(int num[][4]){
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			if(num[i][j] == 0)return 0;
		}
	}
	if(num[3][3] == num[3][2] || num[3][3] == num[2][3])return 0;
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			if(num[i][j] == num[i+1][j] || num[i][j] == num[i][j+1] || num[i][j] == 0)return 0;
		}
	}
	return 1;
}

//��Ϸ����
void the_end(){
	setcolor(WHITE);
	settextstyle(40, 0, _T("����"));
	outtextxy(20,20,_T("��Ϸ����"));
}

//������ǰ����
void now_num(int x,int y,int k){
	int i,j,n=1;
	settextstyle(40, 0, _T("����"));
	setcolor(WHITE);
	if(k<10){
		outtextxy(x,y, k+'0');
	}
	//��outtextxy�ľ����ԣ��ֶ���λÿ������
	else if(k>10){
		j = k;
		while(j >= 10){
			j /= 10;
			n++;
		}
		n = (n-1)*10;
		for(i=n;i>=-n;i-=20){
			outtextxy(x+i, y, k%10+'0');
			k/=10;
		}
	}
}

//�滻��߷���
void high_grade(int num[][4]){
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			if(num[i][j] > grade)grade = num[i][j];
			now_num(350,60,grade);
		}
	}
}

//̧ͷ��ʾ
void text(){
	settextstyle(20, 0, _T("����"));
	setcolor(WHITE);
	outtextxy(30,40,_T("w a s d ����"));
	outtextxy(30,70,_T("��F�ؿ�һ��"));
	outtextxy(250,20,_T("��ǰ��߷�����"));
}

//��ʼ������
void init(int (*num)[4]){
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			num[i][j] = 0;
		}
	}
}

void start_game(){
	text();
	int i[4][4]={0};
	int a[4][4]={0}; //�ö�ά����a���жԱȣ��ж��ܷ������˷����ƶ�
	int j=0;
	char direction;
	create_square(i);
	while(1){
		high_grade(i);
		//draw_array(i);
		copy(a,i);
		direction = getch();
		switch(direction){
		case 'a':
			left(i);
			draw_array(i);
			if(compare(a,i))create_square(i);
			else{
				if(if_end(i))the_end();
			}
			break;
		case 'd':
			right(i);
			draw_array(i);
			if(compare(a,i))create_square(i);
			else{
				if(if_end(i))the_end();
			}
			break;
		case 'w':
			up(i);
			draw_array(i);
			if(compare(a,i))create_square(i);
			else{
				if(if_end(i))the_end();
			}
			break;
		case 's':
			down(i);
			draw_array(i);
			if(compare(a,i))create_square(i);
			else{
				if(if_end(i))the_end();
			}
			break;
		case 'f':
			init(i);
			setcolor(BLACK);
			setfillcolor(BLACK);
			fillrectangle(0,0,200,100);
			text();
			create_square(i);
		default:
			square_clear();
			break;
		}
	}
}
